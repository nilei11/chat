#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/stat.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<pthread.h>
#include<signal.h>
#include<sys/ipc.h>
#include<mysql/mysql.h>

#define PORTNUMBER 2891
#define MAXNUM 50
#define OK 1
#define WRROR 0

int flag_while;
int ret;
//数据库全局变量
MYSQL mysql, *sock;

typedef int Elementtype;
typedef int Status;

//
typedef struct client
{
    char id[100];
 //   Elementtype id_y;
    Elementtype flag;
    Elementtype case_num;
    Elementtype case_numnext;
    char name[100];
    char password[150];
}Client_message;

//
typedef struct server
{
    Elementtype i_s;
    char num_s[MAXNUM][100];
    Elementtype case_snum;
    char id_sname[100];
    Elementtype id_s;
    char name_s[100];
    char password_s[150];
}Server_message;

//链表结构体
typedef struct node
{
    int manager_flag;
    char id_l[100];//    int id_my;
    int fd_l;
    struct node *next;
}linkedlist;

Client_message msg_accept;
Server_message msg_send;
linkedlist *list;

int newfd;
//链表函数
linkedlist *createlinkedlist();
int getcount(linkedlist *list);
linkedlist *insert2(linkedlist *list, char id[30], int fd);
int queryfd(linkedlist *list, char id[30]);
char *queryid(linkedlist *list, int fd);
void printf_list(linkedlist *list);
linkedlist *delinkedllist(linkedlist *list, int fd);   

void need_register(Client_message msg_accept, int sockfd);
void itoa(int i, char *string);
int bind_listenPort(unsigned short int port);
void opandcon_database(void);
void close_database(void);
void *func(void *arg);
void rec_register(int sockfd, int num);
void insert_database(char *id, char *mima);
int search_database(char *str);
void change_database(char *id, char *mima);
void need_register(Client_message msg_accept, int sockfd);
int match_database(Client_message msg_accept, int sockfd);
void change_password(Client_message msg_accept, int sockfd);
void loged_fun(int sockfd);
void self_chat(int sockfd);
void all_chat(int sockfd);
void relieve_banned(int sockfd);
void be_banned(int sockfd);
void out_croom(int sockfd);
void file_send(int sockfd);
void out_chat(int sockfd);

//创建链表
linkedlist *createlinkedlist()
{
    linkedlist *h = NULL;
    return h;
}
//删除链表
linkedlist *delinkedlist(linkedlist *list, int fd)
{
    linkedlist *p = list->next;
    linkedlist *h = list;
    if (list->fd_l == fd)
    {
	free(h);
	return list->next;
    }
    else
    {
	while(p->fd_l != fd)
	{
	    p = p->next;
	    h = h->next;
	}
	h->next = p->next;
	free(p);
	return list;
    }
}
//插入链表
linkedlist *insert2(linkedlist *list, char id[100], int fd)
{
    linkedlist *head, *p;
    head = list;
    p = (linkedlist *)malloc(sizeof(linkedlist));
    if (head == NULL)
    {
	head = p;
	p->next = NULL;
    }
    else
    {
	p->next = head;
	head = p;
    }
    strcpy(p->id_l, id);
    p->fd_l = fd;
    ret = getcount(head);
    if (ret == 1)
    {
	p->manager_flag = 1;
    }
    else 
    {
	p->manager_flag = 0;
    }
    return head;
}
//得到当前在线人数
int getcount(linkedlist *list)
{
    linkedlist *h = list;
    int count = 0;
    while(h != NULL)
    {
	count++;
	h = h->next;
    }
    return count;
}
//将套接字转换为对应的用户名
char *queryid(linkedlist *list, int fd)
{
    linkedlist *h = list;
    while(h != NULL)
    {
	if (fd == h->fd_l)
	{
	    return h->id_l;
	}
	h = h->next;
    }
}
//将用户名转换为对应的套接字
int queryfd(linkedlist *list, char id[100])
{
    linkedlist *h = list;
    while(h != NULL)
    {
	if (strcmp(id, h->id_l) == 0)
	{
	    return h->fd_l;
	}
	h = h->next;
    }
    return 0;
}
//打印当前在线用户
void printf_list(linkedlist *list)
{
    linkedlist *h = list;
    printf("在线的人有：");
    while(h != NULL)
    {
	printf("%s  ",h->id_l);
	h = h->next;
    }
    printf("\n");
}

/*void itoa(int i, char *string)
{
    int mask = 1;
    while (i / mask >= 10)
        mask *= 10;
    while (mask > 0)
    {
        *string++ = i / mask + '0';
        i %= mask;
        mask /= 10;
    }
    *string = '\0';
}*/
 
//得到当前系统的时间
/*void get_cur_time(char *time_str)
{
    struct timeval now;
    gettimeofday(&now, NULL);
    strcpy(time_str, ctime(&now.tv_sec));
}*/
 
 
//端口绑定函数。创建套接字，并绑定到指定端口
int bind_listenPort(unsigned short int port)
{
    int sockfd;
    struct sockaddr_in my_addr;
    sockfd = socket(AF_INET, SOCK_STREAM, 0); //创建基于流套接字
    if (-1 == sockfd)
    {
	printf("socket error\n建立通信失败\n");
    }
    //bzero(&(my_addr.sin_zero),0);
    bzero(&my_addr, sizeof(my_addr));
    my_addr.sin_family = AF_INET; //IPV4协议族
    my_addr.sin_port = htons(port); //转换端口为网络字节序
    my_addr.sin_addr.s_addr = INADDR_ANY;
     
    if (bind(sockfd, (struct sockaddr*)&my_addr, sizeof(struct sockaddr)) == -1)
    {
        perror("bind error\n绑定地址失败\n");
        exit(1);
    }
    printf("bind success\n初始化服务器成功\n");
    if (listen(sockfd, MAXNUM) == -1)
    {
	perror("lisen error\n监听失败\n");
	exit(2);
    }
    printf("listen success\n服务器启动成功\n");
    return sockfd;
}
//开启连接数据库
void opandcon_database(void)
{
    mysql_init(&mysql);
    if (!(sock = mysql_real_connect(&mysql, "localhost", "root", "1", "user", 0, NULL, 0)))
    {
	printf("connect to database error\n");
	exit(1);
    }
    printf("连接数据库成功\n");
}
//关闭数据库
void close_database(void)
{
    mysql_close(&mysql);
    printf("关闭数据库成功\n");
}
//客户端请求修改密码
void change_password(Client_message msg_accept, int sockfd)
{
    printf("用户：%s需要修改密码   密码修改为:%s\n", msg_accept.name, msg_accept.password);
    opandcon_database();
//    printf("msg_name = %s\n", msg_accept.name);
    ret = search_database(msg_accept.name);
    if (ret == 1)
    {
	ret = send(sockfd, "exist", 6, 0);
	if (ret < 0)
	{
	    perror("1111send error");
	    exit(1);
	}
	printf("1111send success\n");
//	rec_register(sockfd, 1);
	change_database(msg_accept.name, msg_accept.password);
    }
    else
    {
	ret = send(sockfd, "none", 8, 0);
	if (ret < 0)
	{
	    perror("2222send error");
	    exit(1);
	}
	printf("2222send success\n");
	rec_register(sockfd, 3);
    }
    close_database();
}
//匹配密码
int match_database(Client_message msg_accept, int sockfd)
{
    int tmpchoice;
    char search[100];
    MYSQL_RES *res = NULL;
    MYSQL_ROW row;
    printf("%s\n", msg_accept.name);
    opandcon_database();
    sprintf(search, "select * from user_inf where ID = '%s'", msg_accept.name);
   ret = mysql_real_query(&mysql, search, strlen(search));
    sleep(1);
    if (ret)
    {
	printf("搜索数据库失败\n");
	exit(3);
    }
    res = mysql_store_result(&mysql);
    row = mysql_fetch_row(res);
    mysql_free_result(res);
    if (row == NULL)
    {
	ret = send(sockfd, "none", 5, 0);
	if (ret <= 0)
	{
	    perror("发送没有该用户失败");
	    exit(1);
	}
	printf("成功告知用户没有该登录用户\n");
	ret = recv(sockfd, &tmpchoice, sizeof(int), 0);
	if (ret <= 0)
	{
	    perror("接受从新选择功能失败");
	}
	printf("成功接受重新选择功能 tmpchoice = %d\n", tmpchoice);
	rec_register(sockfd, tmpchoice);
    }
    else
    {
	char *id = row[0];
	char *user_password = row[1];
	printf("用户名 %s  密码 %s\n", id, user_password);
	if (strcmp(user_password, msg_accept.password) == 0)
	{
	    ret = send(sockfd, "success", 8, 0);
	    if (ret <= 0)
	    {
		perror("发送成功登陆信息失败");
		exit(1);
	    }
	    printf("成功发送登录信息\n");
	    list = insert2(list, msg_accept.name, sockfd);
	    printf_list(list);
	    printf("现在在线人数有:%d\n", getcount(list));
	    man_or_nor(sockfd);
	    sleep(1);
	    flag_while = 1;
	    while(flag_while)
	    {
		loged_fun(sockfd);
	    }
	}
	else
	{
	    ret = send(sockfd, "fail", 5, 0);
	    if (ret <= 0)
	    {
		perror("发送密码不匹配失败");
		exit(1);
	    }
	    printf("成功发送密码不匹配\n");
	    rec_register(sockfd, 2);
	}
    }
    close_database();
}
//判断是否为管理员
int man_or_nor(int sockfd)
{
    int mon;
    if (getcount(list) == 1)
    {
	mon = 1;
    }
    else
    {
	mon = 0;
    }
    sleep(1);
    ret = send(sockfd, &mon, sizeof(int), 0);
    if (ret <= 0)
    {
	perror("send error");
	exit(1);
    }
    printf("发送判断是否为管理员消息成功\n");
}

//查找数据库
int search_database(char *str)
{
    char search[100];
    MYSQL_RES *res = NULL;
    MYSQL_ROW row;
    sprintf(search, "select * from user_inf where ID = '%s'", str);
    ret = mysql_real_query(&mysql, search, strlen(search));
    if (ret)
    {
	printf("search data error\n");
	exit(3);
    }
    res = mysql_store_result(&mysql);
    row = mysql_fetch_row(res);
    mysql_free_result(res);
    if (row == NULL)
    {
	return 0;
    }
    else
    {
	return 1;
    }
}
//修改数据
void change_database(char *id, char *mima)
{
    char write[100];
    sprintf(write, "update user_inf set code = '%s' where ID = '%s'", mima, id);
    ret = mysql_real_query(&mysql, write, strlen(write));
    if (ret != 0)
    {
	printf("修改数据库中密码失败\n");
	exit(1);
    }
    else
    {
	printf("修改数据库中密码成功\n");
    }
}
//插入数据
void insert_database(char *id, char *mima)
{
    char write[100];
    sprintf(write, "insert into user_inf values('%s', '%s')", id, mima);
    ret = mysql_real_query(&mysql, write, strlen(write));
    if(ret)
    {
	printf("数据插入数据库失败\n");
	exit(2);
    }
    printf("数据插入数据库成功\n");

}
//重新从客户端接收信息并选择功能
void rec_register(int sockfd, int num)
{
//    char sendbuff[1024] = {0};
//    char buff[1024] = {0};
    memset(&msg_accept, 0, sizeof(msg_accept));
    ret = recv(sockfd, &msg_accept, sizeof(msg_accept), 0);
    if (ret <= 0)
    {
	perror("重新接收客户端指令失败");
	exit(1);
    }
    printf("成功重新接受客户端指令\n");
//    memset(&msg_accept, 0, sizeof(msg_accept));
//    memcpy(&msg_accept, buff, sizeof(msg_accept));
    if(num == 1)
    {
	need_register(msg_accept, sockfd);
    }
    else if(num ==2)
    {
	match_database(msg_accept, sockfd);
    }
    else if(num == 3)
    {
	change_password(msg_accept, sockfd);
    }
}
//客户端请求注册
void need_register(Client_message msg_accept, int sockfd)
{
    printf("客户端需要注册的名字：%s   密码:%s\n", msg_accept.name, msg_accept.password);
    opandcon_database();
//    printf("msg_name = %s\n", msg_accept.name);
    ret = search_database(msg_accept.name);
    if (ret == 1)
    {
	ret = send(sockfd, "exist", 6, 0);
	if (ret < 0)
	{
	    perror("send error");
	    exit(1);
	}
	printf("send success\n");
	rec_register(sockfd, 1);
    }
    else
    {
	ret = send(sockfd, "success", 8, 0);
	if (ret < 0)
	{
	    perror("send error");
	    exit(1);
	}
	printf("send success\n");
	insert_database(msg_accept.name, msg_accept.password);
    }
    close_database();
}

//查看当前在线用户
void view_user(int sockfd)
{
    char sendbuff[1024] = {0};
    int count = getcount(list);
    msg_send.id_s = count;
    msg_send.case_snum = 1;
    sleep(1);
    linkedlist *h = list;
    int tmp = 0;
    while(h != NULL)
    {
	strncpy(msg_send.num_s[tmp], h->id_l, sizeof(msg_send.num_s[tmp]));
	tmp++;
	h = h->next;
    }
    msg_send.i_s = tmp;
    ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("send error");
	exit(1);
    }
    printf("send success\n");
}
//私聊
void self_chat(int sockfd)
{
    char id_client[100];
    int send_newfd = queryfd(list, msg_accept.id);
    strcpy(id_client, queryid(list, sockfd));
    if (send_newfd != 0)//有此人
    {
	printf("客户端 %s 私聊客户端 %s 消息为:%s\n", id_client, msg_accept.id, msg_accept.name);
	msg_send.id_s = send_newfd;
	msg_send.case_snum = 2;//告诉客户端有该用户
	ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
	if (ret <= 0)
	{
	    perror("告知客户端有该用户失败");
	    exit(1);
	}
	printf("告知客户端有该用户成功\n");
	strcpy(msg_send.name_s, msg_accept.name);
	msg_send.case_snum = 4;
	strcpy(msg_send.id_sname, id_client);
	ret = send(send_newfd, &msg_send, sizeof(msg_send), 0);
	if (ret <= 0)
	{
	    perror("发送私聊消息失败");
	    exit(1);
	}
	printf("发送私聊消息成功\n");
	msg_send.case_snum = 5;
	ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
	if (ret <= 0)
	{
	    perror("告知客户端发送私聊消息失败");
	    exit(1);
	}
	printf("成功告知客户端发送私聊消息成功\n");
    }
    else
    {
	printf("没有该用户\n");
	msg_send.case_snum = 3;
	ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
	if (ret <= 0)
	{
	    perror("告知客户端没有该用户失败");
	    exit(1);
	}
	printf("成功告知客户端没有该用户\n");
    }
}
//群聊
void all_chat(int sockfd)
{
    char id_client[100];
    char sendbuff[1024] = {0};
    strcpy(id_client, queryid(list, sockfd));
    printf("用户 %s 发起群聊， 内容为: %s\n", id_client, msg_accept.name);
    int i;
    linkedlist *h = list;
    for(i = 0; i < getcount(list); i++)
    {
	if (h->fd_l != sockfd)
	{
	    printf("fd_l=%d\n", h->fd_l);
	    memset(sendbuff, 0, 1024);
	    strcpy(msg_send.name_s, msg_accept.name);
	    msg_send.case_snum = 6;
	    strcpy(msg_send.id_sname, id_client);
	    ret = send(h->fd_l, &msg_send, sizeof(msg_send), 0);
	    if (ret <= 0)
	    {
		perror("发送群聊消息失败\n");
		exit(1);
	    }
	    printf("成功发送群聊消息\n");
	}
	h = h->next;
    }
    msg_send.case_snum = 5;
    ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("告知消息发送群聊消息失败");
	exit(1);
    }
    printf("成功告知发送群聊消息成功\n");
}
//客户端请求下线
void out_chat(int sockfd)
{
    char id_client[100];
    char sendbuff[1024] = {0};
    strcpy(id_client, queryid(list, sockfd));
    printf("客户端用户 %s 请求下线\n", id_client);
    list = delinkedlist(list, sockfd);
//    printf_list(list);
    memset(sendbuff, 0, 1024);
    msg_send.case_snum = 7;
    ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("send error");
	exit(1);
    }
    printf("send success\n");
}
//禁言
void be_banned(int sockfd)
{
    printf("管理员请求禁言， 禁言的用户为:%s\n", msg_accept.id);
    int jinyan_newfd = queryfd(list, msg_accept.id);
    msg_send.case_snum = 8;//发送给被禁言的人
    ret = send(jinyan_newfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("告知被禁言的人失败");
	exit(1);
    }
    printf("告知被禁言的人成功\n");
    msg_send.case_snum = 11;//告诉管理员禁言成功
    ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("告知管理员失败");
	exit(1);
    }
    printf("告知管理员成功\n");
}
//解除禁言
void relieve_banned(int sockfd)
{
    printf("管理员请求解除禁言， 禁言的用户为:%s\n", msg_accept.id);
    int jiejin_newfd = queryfd(list, msg_accept.id);
    msg_send.case_snum = 9;//发送给的人
    ret = send(jiejin_newfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("告知被禁言失败");
	exit(1);
    }
    printf("成功告知被禁言\n");
    msg_send.case_snum = 11;//告诉管理员禁言成功
    ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("告知管理员操作成功失败");
	exit(1);
    }
    printf("告诉管理员操作成功\n");
}
//踢人出群
void out_croom(int sockfd)
{
    printf("管理员请求踢人出群， 被踢用户为:%s\n", msg_accept.id);
    int tiren_newfd = queryfd(list, msg_accept.id);
    msg_send.case_snum = 10;//发送给的人
    ret = send(tiren_newfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("send error");
	exit(1);
    }
    printf("send success\n");
    msg_send.case_snum = 11;//告诉管理员禁言成功
    ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("send error");
	exit(1);
    }
    printf("告诉管理员成功\n");
}
//发送文件
void file_send(int sockfd)
{
    char sendbuff[1024];
    int accept_newfd = queryfd(list, msg_accept.id);
    char id_send[100];
    strcpy(id_send, queryid(list, sockfd));
    if (accept_newfd != 0)//有此人
    {
	printf("用户 %s 请求发送文件给用户 %s 文件名为:%s\n", id_send, msg_accept.id, msg_accept.name);
	/*msg_send.id_s = accept_newfd;
	msg_send.case_snum = 2;//告诉客户端有该用户
	ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
	if (ret <= 0)
	{
	    perror("告知客户端有该用户失败");
	    exit(1);
	}
	printf("告知客户端有该用户成功\n");*/
//	memset(sendbuff, 0, 1024);
    	msg_send.case_snum = 12;
    	strcpy(msg_send.id_sname, id_send);
    	strcpy(msg_send.name_s, msg_accept.name);
    	//memcpy(sendbuff, &msg_send, sizeof(msg_send));
    	ret = send(accept_newfd, &msg_send, sizeof(msg_send), 0);
    	if (ret < 0)
    	{
	    perror("告知接收端用户失败\n");
	    exit(1);
	}
//	printf("告知接收端成功\n");
	while(1)
        {
	    char buffer_file[1024];
	    memset(buffer_file, 0, 1024);
	    if (recv(sockfd, buffer_file, sizeof(buffer_file), 0) < 0)
	    {
	        perror("从发送端接受内容失败");
	        exit(1);
	    }
	    printf("从发送端接收内容成功，内容是:\n");
	    printf("%s\n", buffer_file);
	   /* ret = strcmp(buffer_file, "END");
	    if (ret == 0)
	    {
		break;
	    }*/
	    ret = send(accept_newfd, buffer_file, sizeof(buffer_file), 0);
	    if (ret < 0)
	    {
		perror("发送内容给接收端失败\n");
		exit(1);
	    }
	    //printf("发送内容给接收端成功\n");
	    ret = strcmp(buffer_file, "END");
	    if (ret == 0)
	    {
		break;
	    }
	}
	printf("发送成功\n");
	msg_send.case_snum = 13;
	ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
    	if (ret <= 0)
    	{
	    perror("告知发送端失败\n");
	    exit(1);
	}

    }
    else
    {
	printf("没有该用户\n");
	msg_send.case_snum = 3;
	ret = send(sockfd, &msg_send, sizeof(msg_send), 0);
	if (ret <= 0)
	{
	    perror("告知客户端没有该用户失败");
	    exit(1);
	}
	printf("成功告知客户端没有该用户\n");
    }
}
//用户登录后功能选择
void loged_fun(int sockfd)
{
    char buff[1024] = {0};
    memset(buff, 0, 1024);
    ret = recv(sockfd, buff, sizeof(buff), 0);
    if (ret <= 0)
    {
	perror("recv error");
	exit(1);
    }
    printf("得到用户请求操作成功\n");
    memcpy(&msg_accept, buff, sizeof(msg_accept));
    switch(msg_accept.case_numnext)
    {
	case 1://查看当前在线用户
	    {
		view_user(sockfd);
		break;
	    }
	case 2://私聊
	    {
		self_chat(sockfd);
		break;
	    }
	case 3://群聊
	    {
		all_chat(sockfd);
		break;
	    }
	case 4://发送文件
	    {
		file_send(sockfd);
		break;
	    }
	case 5://客户端请求下线
	    {
		out_chat(sockfd);
		flag_while = 0;
		goto out_1;
//		break;
	    }
	case 6://禁言
	    {
		be_banned(sockfd);
		break;
	    }
	case 7://解除禁言
	    {
		relieve_banned(sockfd);
		break;
	    }
	case 8://踢人出群
	    {
		out_croom(sockfd);
		break;
	    }
    }
out_1:
    printf("******************\n");
//    close(newfd);
}

//线程
void *func(void *arg)
{
    int newfd = *(int*)arg;
//    char sendbuff[1024] = {0};
    char buff[1024] = {0};
    static int num = 1000;
    while(1)
    {
	ret = recv(newfd, buff, sizeof(buff), 0);
	if (ret <= 0)
	{
	    perror("recv error\n");
	    exit(1);
	}
	printf("recv success\n");
	memset(&msg_accept, 0, sizeof(msg_accept));
	memcpy(&msg_accept, buff, sizeof(msg_accept));
	switch(msg_accept.case_num)
	{
	    case 1://客户请求注册
		{
		    need_register(msg_accept, newfd);
		    break;
		}
	    case 2://客户请求登录
		{
		    match_database(msg_accept, newfd);
		    break;
		}
	    case 3://客户端请求更改密码
		{
		    change_password(msg_accept, newfd);
		    break;
		}
	    case 4://客户端请求退出
		{
		    printf("用户 %d 请求退出\n", newfd);
		   // close(newfd);
		    goto outroom;
		}
	}
	break;
    }
    pthread_exit(NULL);
outroom:
    close(newfd);
}
int main(int argc, char *argv[])
{
    int newfd;
    list = createlinkedlist();
    char search_name[100];
    system("clear");
    int ret, sock_fd;
    printf("服务器正在初始化......\n");
    sleep(2);
    sock_fd = bind_listenPort(PORTNUMBER);
    pthread_t pid;
    while(1)
    {
	char search_name;
	struct sockaddr_in client_addr;
	int lenth = sizeof(struct sockaddr);
	newfd = accept(sock_fd, (struct sockaddr*)&client_addr, &lenth);
	if (-1 == newfd)
	{
	    perror("accept error\n接受失败\n");
	    exit(1);
	}
	printf("客户端%d连接成功\n", newfd);
	ret = pthread_create(&pid, NULL, (void*)func, (void*)&newfd);
	if (ret != 0)
	{
	    printf("create pthead error\n");
	    exit(1);
	}
	printf("create pthread success\n");
    }
    return 0;
}
