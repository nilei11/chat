#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<netinet/in.h>
#include<pthread.h>

#define PORTNUMBER 2891
#define OK 1
#define ERROR 0

int flag_while;
pthread_t pid;
int ret;
//判断在线情况，1正常在线  2被踢下线  3被禁言
int address_online;
int mon;
typedef int Elementtype;
typedef int Status;

typedef struct client
{
    char id[100];
//    Elementtype id_y;
    Elementtype flag;
    Elementtype case_num;
    Elementtype case_numnext;
    char name[100];
    char password[150];
}Client_message;
//定义一个与服务器一致的结构体
typedef struct server
{
    Elementtype i_s;
    char num_s[50][100];
    Elementtype case_snum;//接收服务器进行的功能选择
    Elementtype id_s;
    char id_sname[100];
    char name_s[100];
    char password_s[150];
}Server_message;

Client_message msg_send;
Server_message msg_accept;

void inter(void);
int funchoice(int sock_fd);
void *func(void *arg);
void fun_choice(int sock_fd);
int connectserver(char *str);
void ask_login(int sock_fd);
void sign_in(int sock_fd);
void change_password(int sock_fd);
void afterlog_normal(void);
void afterlog_mager(void);
//总开始界面
void inter(void)
{
    printf("*********欢迎来到聊天室*********\n");
    printf("********请选择以下功能********\n");
    printf("1.用户注册\n");
    printf("2.用户登录\n");
    printf("3.用户密码更改\n");
    printf("4.退出\n");
}
//普通用户登录后界面
void afterlog_normal(void)
{
    printf("*********您已登陆成功************\n");
    printf("*********您的身份是普通用户请选择以下功能**********\n");
    printf("1.查看当前在线人数情况\n");
    printf("2.进入私聊\n");
    printf("3.进入群聊\n");
    printf("4.文件传输\n");
    printf("5.注销\n");
}
//管理员用户登录后界面
void afterlog_mager(void)
{
    printf("*********您已登陆成功************\n");
    printf("*********您的身份是群主请选择以下功能**********\n");
    printf("1.查看当前在线人数情况\n");
    printf("2.进入私聊\n");
    printf("3.进入群聊\n");
    printf("4.文件传输\n");
    printf("5.注销\n");
    printf("6.禁言\n");
    printf("7.解除禁言\n");
    printf("8.踢人出群\n");
}
//功能选择
int funchoice(int sock_fd)
{
//    sock_fd = connectserver(argv[1]);
    scanf("%d", &msg_send.case_num);
    printf("funchoice num=%d\n", msg_send.case_num);
    switch(msg_send.case_num)
    {
	case 1:
	    {
		sign_in(sock_fd);
		return 1;
		break;
	    }
	case 2:
	    {
		ask_login(sock_fd);
		return 2;
		break;
	    }
	case 3:
	    {
		change_password(sock_fd);
		return 3;
		break;
	    }
	case 4://退出
	    {
	//	out_all(sock_fd);
	        send(sock_fd, &msg_send, sizeof(msg_send),0);
		printf("您已成功退出\n");
		goto outroom;
	//	close(sock_fd);
	    }
    }
    printf("msg_send.case_num=%d\n", msg_send.case_num);
//    return msg_send.case_num;
outroom:
    close(sock_fd);
}
//3用户密码修改
void change_password(int sock_fd)
{
    int tmpchoice;
    char tmp_buf[50];
    char password_tmp[20] = {0}, sendbuff[1024] = {0};
    printf("请输入你的用户名\n");
    scanf("%s", msg_send.name);
    printf("请输入你要修改后的密码\n");
    scanf("%s", msg_send.password);
    printf("请再次输入你要修改后的密码\n");
    scanf("%s", password_tmp);
    if (strcmp(msg_send.password, password_tmp) != 0)
    {
	printf("两次输入的密码不一样，请重新输入想要修改的密码\n");
	change_password(sock_fd);
	exit(0);
    }
    memset(sendbuff, 0, 1024);
    memcpy(sendbuff, &msg_send, sizeof(msg_send));
    ret = send(sock_fd, sendbuff, 1024, 0);
    if (ret <= 0)
    {
	perror("send error\n");
	exit(1);
    }
    printf("send success\n");
    ret = recv(sock_fd, tmp_buf, 50, 0);
    if (ret <= 0)
    {
	perror("receive error");
	exit(2);
    }
    printf("%s\n", tmp_buf);
    if (strcmp(tmp_buf, "none") == 0)
    {
	printf("没有该用户，请选择正确的用户名\n");
	inter();
	tmpchoice = funchoice(sock_fd);
	sleep(1);
	send(sock_fd, &tmpchoice, sizeof(int), 0);
    }
    else
    {
	printf("密码修改成功\n");
    }
}
//连接服务器
int connectserver(char *str)
{
    int sockfd;
    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == sockfd)
    {
	perror("socket error\n建立通信失败\n");
	exit(1);
    }
    struct sockaddr_in client_addr;
    memset(&client_addr, 0, sizeof(client_addr));
    client_addr.sin_family = AF_INET;
    client_addr.sin_port = htons(PORTNUMBER);
    client_addr.sin_addr.s_addr = inet_addr(str);
    if (-1 == connect(sockfd, (struct sockaddr *)&client_addr, sizeof(struct sockaddr)))
    {
	perror("connect error\n连接服务器失败\n");
	exit(2);
    }
    printf("客户端启动成功....\n");
    sleep(2);
    printf("连接服务器成功....\n");
    return sockfd;
}
//1用户注册
void sign_in(int sock_fd)
{
    char tmp_buf[50];
    char password_tmp[20] = {0}, sendbuff[1024] = {0};
    printf("请输入你要注册的用户名\n");
    scanf("%s", msg_send.name);
    printf("请输入你要注册的密码\n");
    scanf("%s", msg_send.password);
    printf("请再次输入你要注册的密码\n");
    scanf("%s", password_tmp);
    if (strcmp(msg_send.password, password_tmp) != 0)
    {
	printf("两次输入的密码不一样，请重新注册\n");
	sign_in(sock_fd);
	exit(0);
    }
    memset(sendbuff, 0, 1024);
    memcpy(sendbuff, &msg_send, sizeof(msg_send));
    ret = send(sock_fd, sendbuff, 1024, 0);
    if (ret <= 0)
    {
	perror("send error\n");
	exit(1);
    }
    printf("send success\n");
    ret = recv(sock_fd, tmp_buf, 50, 0);
    if (ret <= 0)
    {
	perror("receive error");
	exit(2);
    }
    printf("%s\n", tmp_buf);
    if (strcmp(tmp_buf, "exist") == 0)
    {
	printf("已经存在该用户，请重新注册\n");
	sign_in(sock_fd);
	exit(0);
    }
    printf("注册成功\n");
}
//2用户登录
void ask_login(int sock_fd)
{
//    pthread_t pid;
    int tmpchoice;
    char tmp_buf[50];
    char sendbuff[1024] = {0};
    printf("请输入你要登录的用户名\n");
    scanf("%s", msg_send.name);
    printf("请输入你的密码\n");
    scanf("%s", msg_send.password);
    memset(sendbuff, 0, 1024);
    memcpy(sendbuff, &msg_send, sizeof(msg_send));
    ret = send(sock_fd, sendbuff, sizeof(sendbuff), 0);
 //   ret = send(sock_fd, &msg_send, sizeof(msg_send), 0);
    if (ret <= 0)
    {
	perror("发送用户名，密码失败");
	exit(1);
    }
    printf("成功发送用户名，密码\n");
    ret = recv(sock_fd, tmp_buf, 50, 0);
    if (ret <= 0)
    {
	perror("接受登录信号失败");
	exit(2);
    }
    printf("成功接受登录信号\n");
    if (strcmp(tmp_buf, "none") == 0)
    {
	printf("没有该用户，请选择正确的用户名或注册该用户\n");
	inter();
	scanf("%d", &tmpchoice);
/*	tmpchoice = funchoice(sock_fd);
	printf("tmpchoice=%d\n", tmpchoice);*/
//	sleep(1);
	send(sock_fd, &tmpchoice, sizeof(int), 0);
	if (tmpchoice == 1)
	{
	    sign_in(sock_fd);
	}
	else if (tmpchoice == 2)
	{
	    ask_login(sock_fd);
	}
	else if (tmpchoice == 3)
	{
	    change_password(sock_fd);
	}
/*	else if (tmpchoice == 4)
	{
	    out_all(sock_fd);
	}*/
//	exit(0);
    }
    else if(strcmp(tmp_buf, "fail") == 0)
    {
	printf("密码输入错误，请重新输入\n");
	ask_login(sock_fd);
    }
    else
    {
	printf("输入正确，登录成功\n");
	address_online = 1;
	flag_while = 1;
	ret = recv(sock_fd, &mon, sizeof(int), 0);
	if (ret <= 0)
	{
	    perror("recv error\n");
	    exit(1);
	}
//	printf("得到管理员或普通用户信息, mon = %d\n", mon);
	sleep(1);
	ret = pthread_create(&pid, NULL, (void*)func, (void*)&sock_fd);
	if (ret == -1)
	{
	    perror("创建线程失败\n");
	    exit(1);
	}
	while(flag_while)
	{
	    fun_choice(sock_fd);
	}
    }
}
 
//登陆成功后选择功能
void fun_choice(int sock_fd)
{
    if (2 == address_online)
    {
	flag_while = 0;
    	inter();//调用总开始界面
    	funchoice(sock_fd);
	goto outroom;
    }
    char sendbuff[1024];
    if (mon == 0)
    {
	afterlog_normal();
    }
    else if (mon == 1)
    {
	afterlog_mager();
    }		
    scanf("%d", &msg_send.case_numnext);
  /*  if (2 == address_online)
    {
//	goto out;//完成踢人操作
    }*/
    switch(msg_send.case_numnext)
    {
	case 1://查看当前登录用户
	    {
		memset(sendbuff, 0, 1024);
		memcpy(sendbuff, &msg_send, sizeof(msg_send));
		ret = send(sock_fd, sendbuff, sizeof(sendbuff), 0);
		if (ret <= 0)
		{
		    perror("send error");
		    exit(0);
		}
		printf("已向服务器发送查看当前用户求，请稍等......\n");
		sleep(2);
		break;
	    }
	case 2://私聊
	    {
		if (3 != address_online)
		{
		    memset(sendbuff, 0, 1024);
		    printf("请输入你要私聊的用户名\n");
		    scanf("%s", msg_send.id);
		    printf("请输入你要私聊的内容\n");
		    scanf("%s", msg_send.name);
		    memcpy(sendbuff, &msg_send, sizeof(msg_send));
		    ret = send(sock_fd, sendbuff, sizeof(sendbuff), 0);
		    if (ret <= 0)
		    {
		        perror("发送数据失败\n");
		        exit(1);
		    }
		    printf("已向服务器发送私聊请求，请稍等......\n");
		    sleep(2);
		}
		else
		{
		    printf("不好意思,您被禁言了\n");
		}
		break;
	    }
	case 3://群聊
	    {
		if (3 != address_online)
		{
		memset(sendbuff, 0, 1024);
		printf("请输入你要群聊的内容\n");
		scanf("%s", msg_send.name);
		memcpy(sendbuff, &msg_send, sizeof(msg_send));
		ret = send(sock_fd, sendbuff, sizeof(sendbuff), 0);
		if (ret <= 0)
		{
		    perror("发送数据失败\n");
		    exit(1);
		}
		printf("已向服务器发送群聊请求，请稍等......\n");
		sleep(2);
		}
		else
		{
		    printf("不好意思,您被禁言了\n");
		}
		break;
	    }
	case 4://发送文件
	    {
		memset(sendbuff, 0, 1024);
		printf("请输入接收文件用户名:\n");
		scanf("%s", msg_send.id);
		printf("请输入你要发送的文件的名字\n");
		scanf("%s", msg_send.name);
		ret = send(sock_fd, &msg_send, sizeof(msg_send), 0);
		if (ret <= 0)
		{
		    perror("send error");
		}
		printf("成功发送文件名和接受用户的用户名\n");
	//	sleep(10);
		FILE *fp = fopen(msg_send.name, "r");
		if (fp == NULL)
		{
		    perror("fopen error");
		    exit(1);
		}
		printf("打开文件成功\n");
		char buffer_file[1024];
		memset(buffer_file, 0, 1024);
		int file_block_lenth = 0;
		while((file_block_lenth = fread(buffer_file, sizeof(char), 1024, fp)) > 0)
		{
		    printf("length = %d\n", file_block_lenth);
		    printf("buffer=%s\n", buffer_file);
		    ret = send(sock_fd, buffer_file, file_block_lenth, 0);
		    if (ret < 0)
		    {
			printf("2发送文件失败\n");
			exit(1);
		    }
		    printf("成功发送文件\n");
		    memset(buffer_file, 0, 1024);
		}
		fclose(fp);
		strncpy(buffer_file, "END", 4);
		printf("111111\n");
		printf("发送的文件是:%s\n", buffer_file);
		sleep(1);
		ret = send(sock_fd, buffer_file, sizeof(buffer_file), 0);
		if (ret < 0)
		{
		    printf("2发送文件失败\n");
		    exit(1);
		}
		break;
	    }
	case 5://注销
	    {
		memset(sendbuff, 0, 1024);
		char str_tmp[10];
		printf("请确认您是否需要下线\n输入：yes继续下线\n输入：no取消下线\n");
		scanf("%s", str_tmp);
		if (strcmp(str_tmp, "yes") == 0)
		{
		    memcpy(sendbuff, &msg_send, sizeof(msg_send));
		    ret = send(sock_fd, sendbuff, sizeof(sendbuff), 0);
		    if (ret <= 0)
		    {
			perror("发送数据失败\n");
			exit(1);
		    }
		    printf("已向服务器发送下线请求，请稍等......\n");
		    flag_while = 0;
		    sleep(2);
    		    inter();//调用总开始界面
    		    funchoice(sock_fd);
		    break;
		}
		else
		{
		    break;
		}
	    }
	case 6://禁言
	    {
//		memset(sendbuff, 0, sizeof(sendbuff));
		printf("请输入你要禁言的用户名\n");
		scanf("%s", msg_send.id);
		ret = send(sock_fd, &msg_send, sizeof(msg_send), 0);
		if (ret <= 0)
		{
		    perror("send error");
		    exit(1);
		}
		printf("已向服务器发送禁言请求，请稍等......\n");
		break;
	    }
	case 7://解除禁言
	    {
		printf("请输入你要解除禁言的用户名:\n");
		scanf("%s", msg_send.id);
		ret = send(sock_fd, &msg_send, sizeof(msg_send), 0);
		if (ret <= 0)
		{
		    perror("send error");
		    exit(1);
		}
		printf("已向服务器发送解除禁言请求，请稍等......\n");
		break;
	    }
	case 8://踢人出群
	    {
		printf("请输入你要踢出群的用户名\n");
		scanf("%s", msg_send.id);
		ret = send(sock_fd, &msg_send, sizeof(msg_send), 0);
		if (ret <= 0)
		{
		    perror("send error");
		    exit(1);
		}
		printf("已向服务器发送踢人出群请求，请稍等......\n");
		break;
	    }
    }
outroom:
    printf("**********************\n");
}

//线程
void *func(void *arg)
{
    int sock_fd = *(int*)arg;
    char buff[1024] = {0};
    while(1)
    {
	memset(buff, 0, sizeof(buff));
	ret = recv(sock_fd, &msg_accept, sizeof(msg_accept), 0);
	if (ret < 0)
	{
	    perror("recv error");
	    exit(1);
	}
	switch(msg_accept.case_snum)
	{
	    case 1://在线情况
		{
		    printf("现在有 %d 人在线， 在线的用户有:\n", msg_accept.i_s);
		    int i;
		    for(i = 0; i < msg_accept.i_s; i++)
		    {
			printf("%s\n",msg_accept.num_s[i]);
		    }
		    break;
		}
	    case 2://查询端口号有人
		{
	//	    printf("存在该用户, 他的客户端端口号为:%d", msg_accept.id_s);
		    printf("存在该用户");
		    break;
		}
	    case 3://查询端口号没有人
		{
		    printf("查询失败，现在没有这个用户\n");
		    break;
		}
	    case 4://接受私聊消息
		{
		    printf("成员 %s 给你发来消息\n消息是:%s\n", msg_send.name, msg_accept.name_s);
		    break;
		}
	    case 5://消息发送成功
		{
		    printf("您的消息已发送成功\n");
		    break;
		}
	    case 6://接受群聊消息
		{
		    printf("成员 %s 发来群聊消息\n消息是:%s\n", msg_accept.id_sname, msg_accept.name_s);
	//	    char id_sname[100];
		    break;
		}
	    case 7://接受下线成功消息
		{
		    sleep(1);
		    printf("下线成功\n");
		    goto out_1;
		}
	    case 8://普通用户接受被禁言消息
		{
		    printf("您已被管理员禁言\n");
		    address_online = 3;
		    break;
		}
	    case 9://普通用户接受解除禁言消息
		{
		    printf("您已被解除禁言，可以发送消息了\n");
		    address_online = 1;
		    break;
		}
	    case 10://普通用户接受被管理员踢出群消息
		{
		    printf("您已被管理员踢出群\n");
		    msg_send.case_numnext = 5;
		    ret = send(sock_fd, &msg_send, sizeof(msg_send), 0);
		    if (ret <= 0)
		    {
			perror("send error");
			exit(1);
		    }
		    address_online = 2;
		    fun_choice(sock_fd);
		    break;
		}
	    case 11://群主接受命令执行成功
		{
		    printf("群主，你对普通用户所执行的操作成功\n");
		    break;
		}
	    case 12://接受文件
		{
		    printf("用户 %s 给你发来文件， 文件名为: %s\n", msg_accept.id_sname, msg_accept.name_s);
		    char buffer_file[1024];
		    char *str;
		    //printf("请输入你要另存文件的名字:\n");
		   // scanf("%s", str);
		    str = strrchr(msg_accept.name_s, '/');
		    FILE *fp = fopen(str + 1, "w");
		    if (NULL == fp)
		    {
			perror("打开文件失败\n");
			exit(1);
		    }
		    memset(buffer_file, 0, 1024);
		    int length = 0;
		    while(1)
		    {
			length = recv(sock_fd, buffer_file, sizeof(buffer_file), 0);
			if (length < 0)
			{
			    perror("接受文件内容失败");
			    exit(1);
			}
			printf("接受文件内容成功，内容是:\n");
			printf("%s\n", buffer_file);
			if (0 == strcmp(buffer_file, "END"))
			{
			    printf("文件接收完成");
			    break;
			}
			int write_length = fwrite(buffer_file, sizeof(char), length, fp);
			if (write_length < length)
			{
			    perror("写入文件失败\n");
			    break;
			}
		    }
		    fclose(fp);
		    break;
		}
	    case 13:
		{
		    printf("发送成功\n");
		    break;
		}
	}
    }
out_1:
    printf("********************\n");
}
int main(int argc, char *argv[])
{
    if (argc < 2)
    {
	printf("输入错误\n");
    }
    int ret, sock_fd;
    system("clear");
    printf("正在启动客户端....\n");
    sleep(2);
    if (argc != 2)
    {
	printf("error input\n");
	exit(0);
    }
    sock_fd = connectserver(argv[1]);
    inter();//调用总开始界面
    funchoice(sock_fd);
    return 0;
}






