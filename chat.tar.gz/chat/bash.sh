#!/bin/bash
make
gnome-terminal -t "1" -x bash -c "./server;exec bash"
sleep 2
ip=`ifconfig eth0 | awk -F '[ :]+' 'NR==2{print $4}'`
gnome-terminal -t "2" -x bash -c "./client $ip;exec bash"
sleep 1
gnome-terminal -t "3" -x bash -c "./client $ip;exec bash"

